package candylandgame;

public class Kidnapper {

	final int GROUND = 382;
	final int MOVESPEED = 10;
	private int centerX = 50;
	private int centerY = GROUND - 39;
	private int speedX = 0;  
	private int speedY = 1;
	private boolean ducked = false;
	private static Background bg1 = StartingClass.getBg1();
	private static Background bg2 = StartingClass.getBg2();
	
	

	public void update() {

		// Moves Character or Scrolls Background accordingly.

		if (centerX + speedX <= 60) {
			centerX = 61;
		}
	}

	public void moveRight() {
		if (ducked == false) {
			speedX = MOVESPEED;
		}
	}

	public int getCenterX() {
		return centerX;
	}

	public void setCenterX(int centerX) {
		this.centerX = centerX;
	}

	public int getCenterY() {
		return centerY;
	}

	public void setCenterY(int centerY) {
		this.centerY = centerY;
	}

	public int getSpeedX() {
		return speedX;
	}

	public void setSpeedX(int speedX) {
		this.speedX = speedX;
	}

	public int getSpeedY() {
		return speedY;
	}

	public void setSpeedY(int speedY) {
		this.speedY = speedY;
	}

	public boolean isDucked() {
		return ducked;
	}

	public void setDucked(boolean ducked) {
		this.ducked = ducked;
	}

	public static Background getBg1() {
		return bg1;
	}

	public static void setBg1(Background bg1) {
		Kidnapper.bg1 = bg1;
	}

	public static Background getBg2() {
		return bg2;
	}

	public static void setBg2(Background bg2) {
		Kidnapper.bg2 = bg2;
	}

	public int getGROUND() {
		return GROUND;
	}

	public int getMOVESPEED() {
		return MOVESPEED;
	}

}
