package candylandgame;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import candylandgame.framework.Animation;
//Skills learned from http://www.kilobolt.com/
public class StartingClass extends Applet implements Runnable, KeyListener {
	enum GameState {
		Running, Dead
	}


	GameState state = GameState.Running;

	private static Robot robot; //player
	private Kidnapper kidnapper; 
	public static Heliboy hb, hb2, hb3, hb4, hb5, hb6, hb7, hb8, hb9; //Enemy
	public static int score = 0;
    private Font font = new Font(null, Font.BOLD, 30);
	private Image image, currentSprite, character, character2, character3,
			characterDown, characterJumped, characterShoot1, characterShoot2, background1, background2, background3, background4, background5, 
			background6, background7, background8, background9 ,background10, background11, background12, background13, background14, heliboy, heliboy2,
			heliboy3, heliboy4, heliboy5, van, van2, van3, van4, van5;
	public static Image tilegrassTop, tilegrassBot, tilegrassLeft,
			tilegrassRight, tiledirt;
	private URL base;
	private Graphics second;
	private Animation anim, hanim, vanim, banim; //anim is for player, hanim is for enemy, vanim is for kidnapper, banim is for background
	private double timer = System.currentTimeMillis();
	private double timer2 = 0;

	private ArrayList<Tile> tilearray = new ArrayList<Tile>();

	private static Background bg1, bg2;

	@Override
	public void init() {  //initializes
		setSize(800, 480);
		setBackground(Color.BLACK);
		setFocusable(true);
		addKeyListener(this);
		Frame frame = (Frame) this.getParent().getParent();
		frame.setTitle("Candyland");
		try {
			base = getDocumentBase();
		} catch (Exception e) {
			// TODO: Handle Exception
		}

		// image setup
		character = getImage(base, "data/character.png"); // player
		character2 = getImage(base, "data/character2.png");
		character3 = getImage(base, "data/character3.png");
		characterShoot1 = getImage(base, "data/characterShoot1.png");
		characterShoot2 = getImage(base, "data/characterShoot2.png");

		van = getImage(base, "data/van.png"); //kidnapper
		van2 = getImage(base, "data/van2.png");
		van3 = getImage(base, "data/van3.png");
		van4 = getImage(base, "data/van4.png");
		van5 = getImage(base, "data/van5.png");

		characterDown = getImage(base, "data/down.png");
		characterJumped = getImage(base, "data/jumped.png");

		heliboy = getImage(base, "data/cop.png"); //enemy
		heliboy2 = getImage(base, "data/cop.png");
		heliboy3 = getImage(base, "data/cop.png");
		heliboy4 = getImage(base, "data/cop.png");
		heliboy5 = getImage(base, "data/cop.png");

		background1 = getImage(base, "data/background.png");
		background2 = getImage(base, "data/background2.png");
		background3 = getImage(base, "data/background3.png");
		background4 = getImage(base, "data/background4.png");
		background5 = getImage(base, "data/background5.png");
		background6 = getImage(base, "data/background6.png");
		background7 = getImage(base, "data/background7.png");
		background8 = getImage(base, "data/background8.png");
		background9 = getImage(base, "data/background9.png");
		background10 = getImage(base, "data/background10.png");
		background11 = getImage(base, "data/background11.png");
		background12 = getImage(base, "data/background12.png");
		background13 = getImage(base, "data/background13.png");
		background14 = getImage(base, "data/background14.png");
		
		tiledirt = getImage(base, "data/tiledirt.png");
		tilegrassTop = getImage(base, "data/tilegrasstop.png");
		tilegrassBot = getImage(base, "data/tilegrassbot.png");
		tilegrassLeft = getImage(base, "data/tilegrassleft.png");
		tilegrassRight = getImage(base, "data/tilegrassright.png");

		anim = new Animation(); //for player
		anim.addFrame(character, 100);
		anim.addFrame(character2, 100);
		anim.addFrame(character3, 100);
		anim.addFrame(character2, 100);

		hanim = new Animation(); //for enemy
		hanim.addFrame(heliboy, 100);
		hanim.addFrame(heliboy2, 100);
		hanim.addFrame(heliboy3, 100);
		hanim.addFrame(heliboy4, 100);
		hanim.addFrame(heliboy5, 100);
		hanim.addFrame(heliboy4, 100);
		hanim.addFrame(heliboy3, 100);
		hanim.addFrame(heliboy2, 100);
		
		vanim = new Animation(); //for kidnapper
		vanim.addFrame(van, 60);
		vanim.addFrame(van2, 60);
		vanim.addFrame(van3, 60);
		vanim.addFrame(van4, 60);
		vanim.addFrame(van5, 60);
		vanim.addFrame(van4, 60);
		vanim.addFrame(van3, 60);
		vanim.addFrame(van2, 60);
		
		banim = new Animation();
		banim.addFrame(background1, 190);
		banim.addFrame(background2, 190);
		banim.addFrame(background3, 190);
		banim.addFrame(background4, 190);
		banim.addFrame(background5, 190);
		banim.addFrame(background6, 190);
		banim.addFrame(background7, 190);
		banim.addFrame(background8, 190);
		banim.addFrame(background9, 190);
		banim.addFrame(background10, 190);
		banim.addFrame(background11, 190);
		banim.addFrame(background12, 190);
		banim.addFrame(background13, 190);
		banim.addFrame(background14, 190);

		currentSprite = anim.getImage();

	}

	@Override
	public void start() {
		bg1 = new Background(0, 0);
		bg2 = new Background(2160, 0);
		robot = new Robot();

		// Initialize Tiles

		try {
			loadMap("data/map1.txt");
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	
		kidnapper = new Kidnapper();
		hb = new Heliboy(9000, 400);
		hb2 = new Heliboy(3400, 350);
		hb3 = new Heliboy(6000, 400);
		hb4 = new Heliboy(11330, 400);
		hb5 = new Heliboy(14000, 400);
		hb6 = new Heliboy(10140, 267);
		hb7 = new Heliboy(18000, 400);
		hb8 = new Heliboy(33000, 400);
		hb9 = new Heliboy(65000, 400);
		Thread thread = new Thread(this);
		thread.start();


	}

	private void loadMap(String filename) throws IOException { // reads map from data/ map1.txt
		ArrayList lines = new ArrayList();
		int width = 0;
		int height = 0;

		BufferedReader reader = new BufferedReader(new FileReader(filename));
		while (true) {
			String line = reader.readLine();
			
			if (line == null) {
				reader.close();
				break;
			}

			if (!line.startsWith("!")) {
				lines.add(line);
				width = Math.max(width, line.length());

			}
		}
		height = lines.size();

		for (int j = 0; j < 12; j++) {
			String line = (String) lines.get(j);
			for (int i = 0; i < width; i++) {
				System.out.println(i + "is i ");

				if (i < line.length()) {
					char ch = line.charAt(i);
					Tile t = new Tile(i, j, Character.getNumericValue(ch));
					tilearray.add(t);
				}

			}
		}

	}

	@Override
	public void stop() {
		

	}

	@Override
	public void destroy() {
		

	}

	@Override
	public void run() {
		
		if (state == GameState.Running) {
		while (true) {

			robot.update();
			if (robot.isJumped()) {
				currentSprite = characterJumped;
			} else if (robot.isJumped() == false && robot.isDucked() == false) {
				currentSprite = anim.getImage();
			}

			ArrayList projectiles = robot.getProjectiles();
			for (int i = 0; i < projectiles.size(); i++) {
				Projectile p = (Projectile) projectiles.get(i);
				if (p.isVisible() == true) {
					p.update();
				} else {
					projectiles.remove(i);
				}
			}
			updateTiles();
			hb.update();
			hb2.update();
			hb3.update();
			hb4.update();
			hb5.update();
			hb6.update();
			hb7.update();
			hb8.update();
			bg1.update();
			bg2.update();
			

			animate();
			repaint();

			try {
				Thread.sleep(17);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			if (robot.getCenterY() > 500) {
				state = GameState.Dead;
			}
			
		}
		}

	}

	public void animate() {
		anim.update(10);
		hanim.update(50);
		// kidnapper edit
		vanim.update(10);
		banim.update(15);
	}

	@Override
	public void update(Graphics g) {
		if (image == null) {
			image = createImage(this.getWidth(), this.getHeight());
			second = image.getGraphics();
		}

		second.setColor(getBackground());
		second.fillRect(0, 0, getWidth(), getHeight());
		second.setColor(getForeground());
		paint(second);

		g.drawImage(image, 0, 0, this);
		if (Enemy.hope == 2) {
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, 800, 480);
			g.setColor(Color.WHITE);
			g.drawString("Game Over", 360, 240); 
		}
		
		
		}

	

	@Override
	public void paint(Graphics g) {
		if (state == GameState.Running) {
		g.drawImage(banim.getImage(), (int) bg1.getBgX(), (int) bg1.getBgY(), this);
		g.drawImage(banim.getImage(), (int) bg2.getBgX(), (int) bg2.getBgY(), this);
		paintTiles(g);

		ArrayList projectiles = robot.getProjectiles();
		for (int i = 0; i < projectiles.size(); i++) {
			Projectile p = (Projectile) projectiles.get(i);
			g.setColor(Color.YELLOW);
			g.fillRect(p.getX(), p.getY(), 10, 5);
		}
		// For debugging purposes, draws the collison boxes for the player
	/*	g.drawRect((int)robot.rect.getX(), (int)robot.rect.getY(), (int)robot.rect.getWidth(), (int)robot.rect.getHeight());
		g.drawRect((int)robot.rect2.getX(), (int)robot.rect2.getY(), (int)robot.rect2.getWidth(), (int)robot.rect2.getHeight());
		g.drawRect((int)robot.rect3.getX(), (int)robot.rect3.getY(), (int)robot.rect3.getWidth(), (int)robot.rect3.getHeight());
		g.drawRect((int)robot.rect4.getX(), (int)robot.rect4.getY(), (int)robot.rect4.getWidth(), (int)robot.rect4.getHeight());
		g.drawRect((int)robot.yellowRed.getX(), (int)robot.yellowRed.getY(), (int)robot.yellowRed.getWidth(), (int)robot.yellowRed.getHeight());
		g.drawRect((int)robot.footleft.getX(), (int)robot.footleft.getY(), (int)robot.footleft.getWidth(), (int)robot.footleft.getHeight());
		g.drawRect((int)robot.footright.getX(), (int)robot.footright.getY(), (int)robot.footright.getWidth(), (int)robot.footright.getHeight());
		
		*/
		
		
		
		g.drawImage(currentSprite, robot.getCenterX() - 61,
				robot.getCenterY() - 63, this);
		g.drawImage(hanim.getImage(), hb.getCenterX() - 48,
				hb.getCenterY() - 48, this);
		g.drawImage(hanim.getImage(), hb2.getCenterX() - 48,
				hb2.getCenterY() - 48, this);
		g.drawImage(hanim.getImage(), hb3.getCenterX() - 48,
				hb3.getCenterY() - 48, this);
		g.drawImage(hanim.getImage(), hb4.getCenterX() - 48,
				hb4.getCenterY() - 48, this);
		g.drawImage(hanim.getImage(), hb5.getCenterX() - 48,
				hb5.getCenterY() - 48, this);
		g.drawImage(hanim.getImage(), hb6.getCenterX() - 48,
				hb6.getCenterY() - 48, this);
		g.drawImage(hanim.getImage(), hb6.getCenterX() - 48,
				hb6.getCenterY() - 48, this);
		g.drawImage(hanim.getImage(), hb7.getCenterX() - 48,
				hb7.getCenterY() - 48, this);
		g.drawImage(hanim.getImage(), hb8.getCenterX() - 48,
				hb8.getCenterY() - 48, this);
		
		g.drawImage(vanim.getImage(), kidnapper.getCenterX() - 61,
				kidnapper.getCenterY() - 90, this);
		g.setFont(font);
		g.setColor(Color.WHITE);
		g.drawString(Integer.toString(score), 740, 30);	
		} else if (state == GameState.Dead) {
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, 800, 480);
			g.setColor(Color.WHITE);
			g.drawString("Game Over", 360, 240);
			


		}
		}
	

	private void updateTiles() {

		for (int i = 0; i < tilearray.size(); i++) {
			Tile t = (Tile) tilearray.get(i);
			t.update();
		}

	}

	private void paintTiles(Graphics g) {
		for (int i = 0; i < tilearray.size(); i++) {
			Tile t = (Tile) tilearray.get(i);
			g.drawImage(t.getTileImage(), t.getTileX(), t.getTileY(), this);
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
	
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			System.out.println("Move up");
			break;

		case KeyEvent.VK_RIGHT:
			robot.moveRight();
			robot.setMovingRight(true);
			break;
		case KeyEvent.VK_SPACE:
			robot.jump();
			break;
		case KeyEvent.VK_CONTROL:
			
		
			// sets delay till able to shoot
			timer2 = System.currentTimeMillis(); 
			if (robot.isJumped() == false
					&& System.currentTimeMillis() - timer >= 10000) {
				
				robot.shoot();
				
				robot.setReadyToFire(false);
			}
			
		
			break;

		}

	}

	@Override
	public void keyReleased(KeyEvent e) {
		
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			System.out.println("Stop Moving Up");
			break;

		case KeyEvent.VK_LEFT:
			robot.stopLeft();
			break;
		case KeyEvent.VK_RIGHT:
			robot.stopRight();
			break;
		case KeyEvent.VK_SPACE:
			break;
		case KeyEvent.VK_CONTROL:
			robot.setReadyToFire(true);
			
			
			break;

		}
		

	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

	public static Background getBg1() {
		return bg1;
	}

	public static Background getBg2() {
		return bg2;
	}

	public static Robot getRobot() {
		return robot;
	}

	public Image getImage() {
		return image;
	}

	public Image getCharacter() {
		return character;
	}

	public URL getBase() {
		return base;
	}

	public Graphics getSecond() {
		return second;
	}

	public void setRobot(Robot robot) {
		this.robot = robot;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public void setCharacter(Image character) {
		this.character = character;
	}

	public void setBase(URL base) {
		this.base = base;
	}

	public void setSecond(Graphics second) {
		this.second = second;
	}
	
}
