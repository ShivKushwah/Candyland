package candylandgame;

import java.awt.Color;
import java.util.Timer;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.ArrayList;
// This class is for the player
public class Robot {
    
	final int JUMPSPEED = -20;    // Jump
	public double MOVESPEED = 7;  //Speed of player  used to be public double MOVESPEED = 7
	final int GROUND = 377;

	private static int centerX = 100;
	private int centerY = GROUND;
	public boolean jumped = false;
	private boolean movingRight = false;
	final private boolean movingLeft = false;
	private boolean ducked = false;
	private boolean readyToFire = true;
	private boolean firing = true;
	private boolean increaseSpeed = true;
	private int placeHoldingVariable = 0;
	private int bobby = 0;
	
	

	private static Background bg1 = StartingClass.getBg1();
	private static Background bg2 = StartingClass.getBg2();

	private static double speedX = 0;
	private static int speedY = 1;                                     
	public static Rectangle rect = new Rectangle(0, 0, 0, 0);           //Create collision boxes
	public static Rectangle rect2 = new Rectangle(0, 0, 0, 0);
	public static Rectangle rect3 = new Rectangle(0, 0, 0, 0);
	public static Rectangle rect4 = new Rectangle(0, 0, 0, 0);
	public static Rectangle yellowRed = new Rectangle(0, 0, 0, 0);
	public static Rectangle footleft = new Rectangle(0,0,0,0);
	public static Rectangle footright = new Rectangle(0,0,0,0);

	private ArrayList<Projectile> projectiles = new ArrayList<Projectile>();         //Projectile

	public void update() {
		// Moves Character or Scrolls Background accordingly.
		if (speedX < 0) {
			centerX += speedX;
		}
		if (speedX == 0 || speedX < 0) {
			bg1.setSpeedX(0);
			bg2.setSpeedX(0);

		}
		if (centerX <= 200 && speedX > 0) {
			centerX += speedX;
		}
		
		if (speedX > 0 && centerX > 200) {
			bg1.setSpeedX(-MOVESPEED/5);
			bg2.setSpeedX(-MOVESPEED/5);
		}

		// Updates Y Position
		centerY += speedY;
		if (centerY + speedY >= GROUND) {
			centerY = GROUND;
		}

		// Handles Jumping
		if (jumped == true) {
			speedY += 1;

			if (centerY + speedY >= GROUND) {
				centerY = GROUND;
				speedY = 0;
				jumped = false;
			}

		}

		// Prevents going beyond X coordinate of 0
		if (centerX + speedX <= 60) {
			centerX = 61;
		}
   
		rect.setRect(centerX - 16, centerY	, 68, 40);
		rect2.setRect(centerX - 16, centerY + 40, 68, 30);
		rect3.setRect(rect.getX(), rect.getY(), 26, 70);
		rect4.setRect(rect.getX() + 42, rect.getY(), 26, 70);
		yellowRed.setRect(centerX - 70, centerY - 100, 180, 180);
		footleft.setRect(centerX - 8, centerY + 50, 15, 15);
		footright.setRect(centerX + 20, centerY + 50, 15, 15);
		
		if (increaseSpeed = true) {
		
			placeHoldingVariable = placeHoldingVariable + 1;
			
		}
		
		if (placeHoldingVariable > 150) {
			
			MOVESPEED = MOVESPEED + 1;
			placeHoldingVariable = 0;
		}

		
	}
	public static void stopCollide(Graphics g) {
		speedX = 0;
		speedY = 0;
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, 800, 480);
		g.setColor(Color.WHITE);
		g.drawString("Dead", 360, 240);
	
	}

	public void moveRight() {
		
			speedX = MOVESPEED;
		}
	

	public void moveLeft() {
		
			speedX = -MOVESPEED;
		}
	

	public void stopRight() {
		setMovingRight(true);
		stop();
	}

	public void stopLeft() {
		
	}

	private void stop() {
		
	}

	public void jump() {
		if (jumped == false) {
			speedY = JUMPSPEED;
			jumped = true;
		}
	}

	public void shoot() {
		if(readyToFire = true) {
		Projectile p = new Projectile(centerX + 30, centerY + 40);
		projectiles.add(p);
		}
	
		
	
	}
	public static int getCenterX() {
		return centerX;
	}

	public int getCenterY() {
		return centerY;
	}

	public boolean isJumped() {
		return jumped;
	}

	public double getSpeedX() {
		return speedX;
	}

	public int getSpeedY() {
		return speedY;
	}
	

	public void setCenterX(int centerX) {
		this.centerX = centerX;
	}

	public void setCenterY(int centerY) {
		this.centerY = centerY;
	}

	public void setJumped(boolean jumped) {
		this.jumped = jumped;
	}

	public void setSpeedX(int speedX) {
		this.speedX = speedX;
	}

	public void setSpeedY(int speedY) {
		this.speedY = speedY;
	}

	public boolean isDucked() {
		return ducked;
	}

	public void setDucked(boolean ducked) {
		this.ducked = ducked;

	}

	public boolean isMovingRight() {
		return movingRight;
	}

	public void setMovingRight(boolean movingRight) {
		this.movingRight = movingRight;
	}



	public ArrayList getProjectiles() {
		return projectiles;
	}

	public boolean isReadyToFire() {
		return readyToFire;
	}

	public void setReadyToFire(boolean readyToFire) {
		this.readyToFire = readyToFire;
	}

	public static Background getBg1() {
		return bg1;
	}

	public static void setBg1(Background bg1) {
		Robot.bg1 = bg1;
	}

	public static Background getBg2() {
		return bg2;
	}

	public static void setBg2(Background bg2) {
		Robot.bg2 = bg2;
	}

	public int getJUMPSPEED() {
		return JUMPSPEED;
	}

	public double getMOVESPEED() {
		return MOVESPEED;
	}

	public int getGROUND() {
		return GROUND;
	}

	public boolean isMovingLeft() {
		return movingLeft;
	}

	public void setProjectiles(ArrayList<Projectile> projectiles) {
		this.projectiles = projectiles;
	}
	public boolean firing() {
		return firing;
	}

	public boolean isFiring() {
		return firing;
	}

	public void setFiring(boolean firing) {
		this.firing = firing;
	}

}
