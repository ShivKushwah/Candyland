package candylandgame;

public class Background {
	private double bgX;
	private double bgY;
	private double speedX;
	
	public Background (int x, int y) {     //Game's Background
		bgX = x;
		bgY = y;
		speedX = 0;
	}
	public void update() {
		//shift in background
		bgX += speedX;
		//loops background
		if (bgX <= -2160) {
			bgX += 4320;
		}
	}
	public double getBgX() {
		return bgX;
	}
	public void setBgX(int bgX) {
		this.bgX = bgX;
	}
	public double getBgY() {
		return bgY;
	}
	public void setBgY(int bgY) {
		this.bgY = bgY;
	}
	public double getSpeedX() {
		return speedX;
	}
	public void setSpeedX(double d) {
		this.speedX = d;
	}


}
